# Import Required Libraries
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, avg, count, desc, regexp_replace, split, explode, when
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from wordcloud import WordCloud
import plotly.express as px


# Step 1: Initialize Spark Session
spark = SparkSession.builder \
    .appName("IMDb Advanced Data Pipeline") \
    .config("spark.sql.shuffle.partitions", "8") \
    .getOrCreate()

# Step 2: Load the Preprocessed Dataset
print("📊 Loading IMDb Merged Dataset...")
df = spark.read.csv('imdb_merged_dataset_preprocessed.csv.gz',
                    header=True, inferSchema=True)

# Display Dataset Schema and Sample Data
df.printSchema()
df.show(5)

# Step 3: Business Questions and Analysis

# Q1: Top 10 Highest-Rated Movies and Success Factors
print("📊 Analyzing Top 10 Highest-Rated Movies...")
top_rated_movies = df.filter(col("averageRating") >= 8.5) \
    .select("primaryTitle", "averageRating", "startYear", "genres") \
    .orderBy(desc("averageRating")) \
    .limit(10)
top_rated_pd = top_rated_movies.toPandas()

# Visualization
plt.figure(figsize=(12, 6))
sns.barplot(data=top_rated_pd, x='averageRating', y='primaryTitle', palette='viridis')
plt.title('Top 10 Highest Rated Movies')
plt.xlabel('Rating')
plt.ylabel('Title')
plt.show()

# Q2: Top-Performing Genres and Their Ratings Across Decades
print("📊 Analyzing Top-Performing Genres...")
avg_rating_by_genre = df.withColumn("Genre", explode(split(col("genres"), ","))) \
    .groupBy("Genre") \
    .agg(avg("averageRating").alias("Avg_Rating")) \
    .orderBy(desc("Avg_Rating")) \
    .limit(10)
avg_rating_pd = avg_rating_by_genre.toPandas()

# Visualization
plt.figure(figsize=(12, 6))
sns.barplot(data=avg_rating_pd, x='Avg_Rating', y='Genre', palette='magma')
plt.title('Top 10 Average Ratings by Genre')
plt.xlabel('Average Rating')
plt.ylabel('Genres')
plt.show()

# Q3: Trends in Movie Production Over Time
print("📊 Analyzing Movie Production Trends Over Years...")
movies_per_year = df.groupBy("startYear").agg(count("primaryTitle").alias("Movie_Count")) \
    .orderBy("startYear")
movies_per_year_pd = movies_per_year.toPandas()

# Visualization
plt.figure(figsize=(12, 6))
sns.lineplot(data=movies_per_year_pd, x='startYear', y='Movie_Count', marker='o')
plt.title('Number of Movies Released Per Year')
plt.xlabel('Year')
plt.ylabel('Number of Movies')
plt.show()

# Q4: Top 10 Actors by Movie Appearances
print("📊 Analyzing Top 10 Actors by Movie Count...")
# Filter out 'Unknown' or null names
top_actors = df.filter((col("primaryName").isNotNull()) & (col("primaryName") != "Unknown")) \
    .groupBy("primaryName") \
    .agg(count("tconst").alias("Movie_Count")) \
    .orderBy(desc("Movie_Count")) \
    .limit(10)

top_actors_pd = top_actors.toPandas()

# Visualization
plt.figure(figsize=(12, 6))
sns.barplot(data=top_actors_pd, x='Movie_Count', y='primaryName', palette='cubehelix')
plt.title('Top 10 Actors by Movie Count')
plt.xlabel('Number of Movies')
plt.ylabel('Actor')
plt.show()


# Q5: Regional Trends in Movie Performance
print("📊 Analyzing Regional Trends in Movie Performance...")
regional_trends = df.groupBy("region") \
    .agg(avg("averageRating").alias("Avg_Rating"), count("tconst").alias("Movie_Count")) \
    .orderBy(desc("Movie_Count")) \
    .limit(10)
regional_trends_pd = regional_trends.toPandas()

# Visualization
plt.figure(figsize=(12, 6))
sns.barplot(data=regional_trends_pd, x='Avg_Rating', y='region', palette='coolwarm')
plt.title('Top 10 Regions by Movie Engagement')
plt.xlabel('Average Rating')
plt.ylabel('Region')
plt.show()

# Q6: Runtime Patterns in Successful Movies
print("📊 Analyzing Runtime Patterns in Successful Movies...")
runtime_analysis = df.filter(col("averageRating") >= 8.0) \
    .groupBy("runtimeMinutes") \
    .agg(avg("averageRating").alias("Avg_Rating")) \
    .orderBy(desc("Avg_Rating")) \
    .limit(10)
runtime_pd = runtime_analysis.toPandas()

# Visualization
plt.figure(figsize=(12, 6))
sns.barplot(data=runtime_pd, x='runtimeMinutes', y='Avg_Rating', palette='viridis')
plt.title('Average Rating by Runtime')
plt.xlabel('Runtime (Minutes)')
plt.ylabel('Average Rating')
plt.show()

# Q7: Historical Trends in Movie Ratings Across Decades
print("📊 Analyzing Historical Trends in Ratings...")
df = df.withColumn("Decade", (col("startYear") / 10).cast("int") * 10)
movies_by_decade = df.groupBy("Decade").agg(count("primaryTitle").alias("Movie_Count")) \
    .orderBy("Decade")
movies_by_decade_pd = movies_by_decade.toPandas()

fig = px.bar(movies_by_decade_pd, x='Decade', y='Movie_Count',
             title='Movies by Decade (Interactive)', color='Movie_Count')
fig.show()

# Q8: WordCloud for Movie Titles
print("📊 Generating Word Cloud for Top Rated Movies...")
title_text = ' '.join(top_rated_pd['primaryTitle'].dropna())
wordcloud = WordCloud(width=800, height=400, background_color='white').generate(title_text)
plt.figure(figsize=(12, 6))
plt.imshow(wordcloud, interpolation='bilinear')
plt.axis('off')
plt.title('Word Cloud of Top Rated Movie Titles')
plt.show()

# Step 5: Save Results to CSV
print("💾 Saving Results...")
top_rated_movies.coalesce(1).write.mode('overwrite').option('header', 'true').csv('output/top_rated_movies.csv')

print("✅ Advanced IMDb Data Pipeline Completed Successfully!")

# Step 6: Stop Spark Session
spark.stop()
