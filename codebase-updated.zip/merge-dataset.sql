
-- Merge Data into a Single Table with a Limit of 10,000 Rows
SELECT DISTINCT
    tb.tconst,
    tb.primaryTitle,
    tb.titleType,
    tb.startYear,
    tb.runtimeMinutes,
    tb.genres,
    tr.averageRating,
    tr.numVotes,
    tp.category,
    nb.primaryName,
    nb.primaryProfession,
    ta.title AS localizedTitle,
    ta.region,
    ta.types
INTO merged_data
FROM title_basics tb
LEFT JOIN title_ratings tr ON tb.tconst = tr.tconst
LEFT JOIN title_principals tp ON tb.tconst = tp.tconst
LEFT JOIN name_basics nb ON tp.nconst = nb.nconst
LEFT JOIN title_akas ta ON tb.tconst = ta.titleId
WHERE tr.averageRating IS NOT NULL;




-- Step 5: Index the Merged Data for Optimization
CREATE INDEX idx_merged_nconst ON merged_data (nconst);
CREATE INDEX idx_merged_tconst ON merged_data (titleId);
CREATE INDEX idx_merged_primaryName ON merged_data (primaryName);

-- Step 6: Test the Merged Table
SELECT TOP 10 * FROM merged_data;

-- Step 7: Export the Merged Table (Optional)
-- Use SSMS's "Export Data" feature to save the merged table to a CSV file.
