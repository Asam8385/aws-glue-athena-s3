 CREATE EXTERNAL TABLE IF NOT EXISTS {DATABASE_NAME}.{TABLE_NAME} (
        tconst STRING,
        primaryTitle STRING,
        titleType STRING,
        startYear INT,
        runtimeMinutes STRING,
        genres STRING,
        averageRating FLOAT,
        numVotes INT,
        category STRING,
        primaryName STRING,
        primaryProfession STRING,
        localizedTitle STRING,
        region STRING,
        types STRING,
        yearGroup STRING
    )
    ROW FORMAT DELIMITED
    FIELDS TERMINATED BY ','
    LINES TERMINATED BY '\n'
    STORED AS TEXTFILE
    LOCATION 's3://preeti-bigdata/imdb_merged_dataset_preprocessed/'
    TBLPROPERTIES ("skip.header.line.count"="1");



-- Query 1: Get Top 10 Highest Rated Titles
SELECT 
    primaryTitle, 
    titleType, 
    averageRating, 
    numVotes 
FROM 
    "imdb_database"."imdb_preprocessed_dataset"
WHERE 
    averageRating IS NOT NULL
ORDER BY 
    averageRating DESC, 
    numVotes DESC
LIMIT 10;

-- Query 2: Count Titles by Genre
SELECT 
    genres, 
    COUNT(*) AS title_count 
FROM 
    "imdb_database"."imdb_preprocessed_dataset"
WHERE 
    genres IS NOT NULL
GROUP BY 
    genres
ORDER BY 
    title_count DESC;

-- Query 3: Most Popular Profession Among Cast/Crew
SELECT 
    primaryProfession, 
    COUNT(*) AS profession_count 
FROM 
    "imdb_database"."imdb_preprocessed_dataset"
WHERE 
    primaryProfession IS NOT NULL
GROUP BY 
    primaryProfession
ORDER BY 
    profession_count DESC
LIMIT 10;

-- Query 4: Count Titles by Year Group
SELECT 
    yearGroup, 
    COUNT(*) AS title_count 
FROM 
    "imdb_database"."imdb_preprocessed_dataset"
GROUP BY 
    yearGroup
ORDER BY 
    yearGroup ASC;

-- Query 5: Find Titles by Specific Region
SELECT 
    primaryTitle, 
    titleType, 
    region, 
    averageRating, 
    numVotes 
FROM 
    "imdb_database"."imdb_preprocessed_dataset"
WHERE 
    region = 'US'
ORDER BY 
    averageRating DESC
LIMIT 20;
