import sys
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from awsglue.utils import getResolvedOptions
from pyspark.sql.functions import col, when

# Step 1: Initialize Glue Context
args = getResolvedOptions(sys.argv, ['JOB_NAME'])
sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
job.init(args['JOB_NAME'], args)

# Step 2: Load Dataset from S3
print("Loading dataset from S3...")
input_path = "s3://preeti-bigdata/imdb_merged_dataset.csv.gz"
df = spark.read.option("header", "true").csv(input_path)

# Step 3: Preprocessing and Transformation
print(" Preprocessing dataset...")
df = df.dropDuplicates()
df = df.fillna({"averageRating": "0", "runtimeMinutes": "0", "primaryName": "Unknown"})
df = df.withColumn("yearGroup", when(col("startYear") < 2000, "Before 2000")
                                    .when((col("startYear") >= 2000) & (col("startYear") < 2010), "2000-2010")
                                    .otherwise("After 2010"))

# Step 4: Save Processed Dataset Back to S3
print(" Saving preprocessed dataset as 'imdb_merged_dataset_preprocessed.csv.gz'...")
output_path = "s3://preeti-bigdata/imdb_merged_dataset_preprocessed"
df.coalesce(1).write.mode("overwrite") \
    .option("header", "true") \
    .option("compression", "gzip") \
    .csv(output_path)

# Step 5: Complete Glue Job
job.commit()
print(" Preprocessing completed. Dataset saved to 'imdb_merged_dataset_preprocessed.csv.gz'")